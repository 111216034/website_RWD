import pygame
import random
import os
import time
from PIL import Image
from pygame.locals import *
import moviepy
from moviepy.editor import *

disappear = False
deter = 0
DELAY = 100
BACKGROUND = (125,209,71)
FPS = 60
HEIGHT = 600
WIDTH = 800
timecard = 80
cardnumber = 0
cardnumber2 = 6
all_sprite = pygame.sprite.Group()
point1 = 0
point2 = 0
playerpoint = 0
cpupoint = 0
move = 0
move2 = 0
font_name = os.path.join('chinese.ttf')
wait = 30


#遊戲初始化
pygame.init()
pygame.display.set_caption("十點半")

screen = pygame.display.set_mode((WIDTH,HEIGHT))
clock = pygame.time.Clock()
running = True
start = True
turn = False

#匯入圖片

numbers = list(range(1, 53))
random.shuffle(numbers)
random_numbers = numbers[:20]

#random1 = str(random_numbers[0])
#card_img = pygame.image.load(os.path.join("Standard 52-card deck",(random1)+".jpg")).convert()
random_numbers.pop(0)
random2 = str(random_numbers[0])
card2_img = pygame.image.load(os.path.join("Standard 52-card deck",(random2)+".jpg")).convert()

#字體設定

def text (surf,text,size,x,y):
    font = pygame.font.Font(font_name,size)
    text_surface = font.render(text,True,(0,0,0))
    text_rect = text_surface.get_rect()
    text_rect.x = x
    text_rect.y = y
    surf.blit(text_surface,text_rect)
def text2 (surf,text,size,x,y):
    font = pygame.font.Font(font_name,size)
    text_surface = font.render(text,True,(255,255,255))
    text_rect = text_surface.get_rect()
    text_rect.x = x
    text_rect.y = y
    surf.blit(text_surface,text_rect)
#音樂設定

pygame.mixer.init()
pygame.mixer.music.load(os.path.join("Standard 52-card deck","y2meta.com-Undertale OST_ 043 - Temmie Village-(128kbps).ogg"))
pygame.mixer.music.play(-1)
pygame.mixer.music.set_volume(0.15)

#按鈕指令

button_rect = pygame.Rect(80, 250, 100, 100)

                    
class plusbuttom(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(os.path.join("Standard 52-card deck","plus.jpg")).convert()
        self.rect = self.image.get_rect()
        self.rect.x = 80
        self.rect.y = 290
    def update(self, events=[]):
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if disappear == False and playerpoint <= 10.5:
                    if self.rect.collidepoint(pos):
                        global cardnumber
                        cardnumber += 1
                        new_card = Card3()
                        all_sprite.add(new_card)
                
    
class plusbuttom2(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(os.path.join("Standard 52-card deck","plus2.jpg")).convert()
        self.rect = self.image.get_rect()
        self.rect.x = 80
        self.rect.y = 50
        
    def update(self, events=[]):
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if cpupoint <= 10.5:
                    if self.rect.collidepoint(pos):
                        global cardnumber
                        cardnumber += 1
                        new_card2 = Card4()
                        all_sprite.add(new_card2)
            
class stopbuttom(pygame.sprite.Sprite):
    def __init__(self, turn):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(os.path.join("Standard 52-card deck","stop.jpg")).convert()
        self.rect = self.image.get_rect()
        self.x = 80
        self.y = 370
        self.turn = turn
        self.rect.x = self.x
        self.rect.y = self.y

    def update(self, events=[]):
        global disappear
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if self.rect.collidepoint(pos):
                        new_buttom = plusbuttom2()
                        all_sprite.add(new_buttom)
                        new_buttom2 = stopbuttom2()
                        all_sprite.add(new_buttom2)
                        disappear = True
                if cardnumber == 4:
                    disappear = True
                        
class stopbuttom2(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(os.path.join("Standard 52-card deck","stop2.jpg")).convert()
        self.rect = self.image.get_rect()
        self.x = 80
        self.y = 130
        self.rect.x = self.x
        self.rect.y = self.y
        
    def update(self, events=[]):
        global deter
        global start
        for event in events:
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if self.rect.collidepoint(pos):
                    print("check")
                    if cpupoint <= playerpoint:
                        start = True
                        deter = 2
                    elif playerpoint < cpupoint:
                        start = True
                        deter = 1
                    elif playerpoint == cpupoint:
                        start = True
                        deter = 4
                    
class restartbutton(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(os.path.join("Standard 52-card deck","restart.jpg")).convert()
        self.rect = self.image.get_rect()
        self.rect.x = 80
        self.rect.y = 210

class startbuttom(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(os.path.join("Standard 52-card deck","start.jpg")).convert()
        self.rect = self.image.get_rect()
        self.x = 570
        self.y = 450
        self.rect.x = self.x
        self.rect.y = self.y



        
#背景程式


def initgame(deter):
    global start_sprite
    global Startbuttom
    if deter == 0:
        background3 = pygame.image.load(os.path.join("Standard 52-card deck","background3.jpg")).convert()
        screen.blit(background3, (0, 0))
        #text2(screen,"遊戲名 : Tem and Half",40,50,320)
        #text2(screen,"遊戲說明:",30,50,370)
        #text2(screen,"玩家一在下方，玩家二在上方",25,60,415)
        #text2(screen,"由玩家二擔任莊家",25,60,450)
        start_sprite = pygame.sprite.Group()
        Startbuttom = startbuttom()
        start_sprite.add(Startbuttom)  # 新增 startbutton
        start_sprite.draw(screen)

    if deter == 1 :
        background = pygame.image.load(os.path.join("Standard 52-card deck","background.jpg")).convert()
        screen.blit(background, (0, 0))
        text2(screen,"玩家二獲勝",60,270,50)
        text2(screen,"玩家一點數"+str(playerpoint),30,100,300)
        text2(screen,"玩家二點數"+str(cpupoint),30,500,300)
        text2(screen,"重新開始",40,330,400)
    elif deter == 2 :
        background = pygame.image.load(os.path.join("Standard 52-card deck","background.jpg")).convert()
        screen.blit(background, (0, 0))
        text2(screen,"玩家一獲勝",60,270,50)
        text2(screen,"玩家一點數"+str(playerpoint),30,100,300)
        text2(screen,"玩家二點數"+str(cpupoint),30,500,300)
        text2(screen,"重新開始",40,330,400)
    elif deter == 3 :
        background = pygame.image.load(os.path.join("Standard 52-card deck","background.jpg")).convert()
        screen.blit(background, (0, 0))
        text2(screen,"玩家二獲勝(十點半)",60,150,50)
        text2(screen,"玩家一點數"+str(playerpoint),30,100,300)
        text2(screen,"玩家二點數"+str(cpupoint),30,500,300)
        text2(screen,"重新開始",40,330,400)
    elif deter == 4 :
        background = pygame.image.load(os.path.join("Standard 52-card deck","background.jpg")).convert()
        screen.blit(background, (0, 0))
        text2(screen,"玩家二獲勝(平手莊家勝)",60,100,50)
        text2(screen,"玩家一點數"+str(playerpoint),30,100,300)
        text2(screen,"玩家二點數"+str(cpupoint),30,500,300)
        text2(screen,"重新開始",40,330,400)
    elif deter == 5 :
        background = pygame.image.load(os.path.join("Standard 52-card deck","background.jpg")).convert()
        screen.blit(background, (0, 0))
        text2(screen,"玩家二獲勝(過五關)",60,150,50)
        text2(screen,"玩家一點數"+str(playerpoint),30,100,300)
        text2(screen,"玩家二點數"+str(cpupoint),30,500,300)
        text2(screen,"重新開始",40,330,400)
    elif deter == 6 :
        background = pygame.image.load(os.path.join("Standard 52-card deck","background.jpg")).convert()
        screen.blit(background, (0, 0))
        text2(screen,"玩家一獲勝(過五關)",60,150,50)
        text2(screen,"玩家一點數"+str(playerpoint),30,100,300)
        text2(screen,"重新開始",40,330,400)

    pygame.display.update()

#角色指令

class Card(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        global cardnumber2
        random4 = str(random_numbers[cardnumber2])
        self.image = pygame.image.load(os.path.join("Standard 52-card deck",(random4)+".jpg")).convert()
        self.rect = self.image.get_rect()
        self.rect.x = 525
        self.rect.y = 30

    def update(self):
        if self.rect.x > 300:
            self.rect.x -= 5

class Card2(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        random3 = str(random_numbers[cardnumber])
        self.image = pygame.image.load(os.path.join("Standard 52-card deck",(random3)+".jpg")).convert()
        self.rect = self.image.get_rect()
        #self.image = card2_img
        #self.rect = self.image.get_rect()
        self.rect.x = 525
        self.rect.y = 30

    def update(self):
        if timecard == 0:
            if self.rect.x > 300:
                self.rect.x -= 5
            if self.rect.y < 300:
                self.rect.y += 5

class Card3(pygame.sprite.Sprite):
    def __init__(self):
        global playerpoint
        global move2
        pygame.sprite.Sprite.__init__(self)
        random3 = str(random_numbers[cardnumber])
        point1 = int(random3) % 13
        self.playerpoint = playerpoint
        self.offset_x = 50 * move2  # 水平偏移量
        move2 += 1
        print("move2="+str(move2))
        self.image = pygame.image.load(os.path.join("Standard 52-card deck",(random3)+".jpg")).convert()
        self.rect = self.image.get_rect()
        self.rect.x = 600
        self.rect.y = 300
        self.changex = 350 + self.offset_x  # 設定 changex 的初值
        if 0 < point1 <= 10:
            playerpoint = playerpoint + point1
        else:
            playerpoint = playerpoint + 0.5
        print("player="+str(playerpoint))

    def update(self):
        if self.changex < self.rect.x:  # 改用 changex 判斷是否需要移動
            self.rect.x -= 5

class Card4(pygame.sprite.Sprite):
    def __init__(self):
        global cpupoint
        global move
        global cardnumber2
        pygame.sprite.Sprite.__init__(self)
        cardnumber2 += 1
        random4 = str(random_numbers[cardnumber2])
        if cardnumber2 == 7:
            point2 = int(random4) % 13
        else:
            point2 = int(random4) % 13

        self.cpupoint = cpupoint
        move += 1
        self.offset_x = 50 * move  # 水平偏移量
        self.changex = 300 + self.offset_x  # 設定 changex 的初值
        self.image = pygame.image.load(os.path.join("Standard 52-card deck",(random4)+".jpg")).convert()
        self.rect = self.image.get_rect()
        self.rect.x = 700
        self.rect.y = 30

        if 0 < point2 <= 10:
            cpupoint = cpupoint + point2
        else:
            cpupoint = cpupoint + 0.5

        print("cpu="+str(cpupoint))
        print("move="+str(move))
    def update(self):
        if self.changex < self.rect.x:  # 改用 changex 判斷是否需要移動
            self.rect.x -= 5
         
class Temmie(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((110,160))
        self.image = pygame.image.load(os.path.join("Standard 52-card deck","temmie.gif")).convert()
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = 300
    def update(self):
        pass



#執行角色
all_sprite = pygame.sprite.Group()
stopbutton2_spirte = pygame.sprite.Group()
plus = plusbuttom()
plus2 = plusbuttom2()
card4 = Card4()
card2 = Card2()
card3 = Card3()
card = Card()
stop = stopbuttom(turn)
all_sprite.add(plus)
all_sprite.add(card2)
all_sprite.add(stop)
all_sprite.add(card)
stop2 = stopbuttom2()
restart = restartbutton()
all_sprite.add(restart)

def restart_game():
    global deter, timecard, cardnumber, cardnumber2, point1, point2, playerpoint, cpupoint, move, move2, wait, numbers, start, all_sprite,random_numbers,card_img,card2_img,disappear
    deter = 0
    timecard = 80
    cardnumber = 0
    cardnumber2 = 6
    point1 = 0
    point2 = 0
    playerpoint = 0
    cpupoint = 0
    move = 0
    move2 = 0
    wait = 30
    disappear = False
    
    numbers = list(random.sample(range(1, 53), 52))
    random_numbers = numbers[:20]
    start = True 
    all_sprite = pygame.sprite.Group()
    stopbutton2_spirte = pygame.sprite.Group()
    plus = plusbuttom()
    plus2 = plusbuttom2()
    card4 = Card4()
    card2 = Card2()
    card3 = Card3()
    card = Card()
    stop = stopbuttom(turn)
    all_sprite.add(plus)
    all_sprite.add(card2)
    all_sprite.add(stop)
    all_sprite.add(card)
    stop2 = stopbuttom2()
    restart = restartbutton()
    all_sprite.add(restart)
    initgame(deter)

while running:

    while start:

        initgame(deter)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                start = False
            
            (x,y) = pygame.mouse.get_pos()
            if 570 < x < 800 and 450 < y < 600 and event.type == pygame.MOUSEBUTTONDOWN and deter == 0:
                start = False
            pygame.display.update()
            if 330 < x < 450 and 400 < y < 500 and event.type == pygame.MOUSEBUTTONDOWN and deter >= 1:
                    # 設定遊戲變數回預設值
                    restart_game()
            if deter == 0:
                for sprite in all_sprite:
                    if isinstance(sprite, restartbutton):
                        if event.type == pygame.MOUSEBUTTONDOWN and sprite.rect.collidepoint(event.pos):
                            restart_game()

                      


    clock.tick(FPS)
    timecard -= 1

    if timecard < 0:
        timecard = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        plus.update([event])  # 更新 plusbuttom 
        plus2.update([event])
        stop.update([event])
        stop2.update([event])
        Startbuttom.update([event])





        # 檢查是否點擊了重新開始按鈕
        if deter == 0:
            for sprite in all_sprite:
                if isinstance(sprite, restartbutton):
                    if event.type == pygame.MOUSEBUTTONDOWN and sprite.rect.collidepoint(event.pos):
                        # 設定遊戲變數回預設值
                            restart_game()
    

    background2 = pygame.image.load(os.path.join("Standard 52-card deck","background2.jpg")).convert()
    screen.blit(background2, (0, 0))
    all_sprite.draw(screen)
    all_sprite.update()
    if playerpoint > 10.5:
        #text(screen,"玩家一大於十點半",30,60,350)
        wait -= 0.5
        if wait <= 0:
            deter = 1
            start = True
    elif cpupoint > 10.5:
        #text(screen,"玩家二大於十點半",30,60,350)
        wait -= 0.5
        if wait <= 0:
            deter = 2
            start = True
    elif playerpoint < 10.5 and cpupoint == 10.5:
        #text(screen,"玩家二等於十點半",30,60,350)
        wait -= 0.5
        if wait <= 0:
            deter = 3
            start = True    
    elif playerpoint == 10.5 and cpupoint == 10.5:
        #text(screen,"玩家一 二等於十點半",30,60,350)
        wait -= 0.5
        if wait <= 0:
            deter = 4
            start = True
    elif move2 < 5 and move == 5 and cpupoint < 10.5:
        #text(screen,"玩家二過五關",30,60,350)
        wait -= 0.5
        if wait <= 0:
            deter = 5
            start = True
    elif move2 == 5 and move < 5 and playerpoint < 10.5:
        #text(screen,"玩家一過五關",30,60,350)
        wait -= 0.5
        if wait <= 0:
            deter = 6
            start = True

        

    pygame.display.update()
    pygame.display.flip()

pygame.quit()